import { world } from "mojang-minecraft";
import * as ui from 'mojang-minecraft-ui';

let rotation

world.events.itemUse.subscribe(eventData => {
    let player = eventData.source
    let item = eventData.item.id
    if (item == "bony:structures") {
        let tags = player.getTags()
        let bony = new ui.ActionFormData();
        bony.title("Created by§f: §5BONY162 §0<- §4YouTube")
        bony.body("§ev1.0 \n§4§lWARNING§0§r: §fThere is no undo yet, make sure to backup your world")
        bony.button("Houses", 'textures/icons/mh_icon.png')
        bony.button('Trees', 'textures/icons/tree_icon.png')
        bony.button("Other", 'textures/icons/ran_icon.png')
        bony.button("Farms (Coming Soon)")
        bony.show(player).then((response) => {
            if (response.isCanceled) return;
            switch (response.selection) {
                case 0:
                    let bony = new ui.ActionFormData();
                    bony.title("House Style")
                    bony.button('Modern', 'textures/icons/mh_icon.png')
                    bony.button('Medival', 'textures/icons/md_icon.png')
                    bony.button("Other")
                    bony.show(player).then((response) => {
                        if (response.isCanceled) return;
                        switch (response.selection) {
                            case 0:
                                let houses = new ui.ModalFormData();
                                houses.title("Select your structure ")
                                houses.dropdown("Houses", ['Modern House 1', 'Modern House 2', 'Modern House 3', 'Modern House 4', 'Modern House 5', 'Modern House 6', 'Modern House 7', 'Modern House 8', 'Modern House 9', 'Modern House 10', 'Modern House 11', 'Modern House 12', 'Modern House 13', 'Modern House 14', 'Modern House 15', 'Modern House 16', 'Modern House 17', 'Modern House 18', 'Modern House 19', 'Modern House 20'])
                                houses.dropdown("Rotation", ['0_degrees', '90_degrees', '180_degrees', '270_degrees'], 0)

                                houses.show(player).then((response) => {
                                    switch (response.formValues[1]) {
                                        case 0:
                                            rotation = '0_degrees'
                                            break
                                        case 1:
                                            rotation = '90_degrees'
                                            break
                                        case 2:
                                            rotation = '180_degrees'
                                            break
                                        case 3:
                                            rotation = '270_degrees'
                                            break
                                    }
                                    if (response.isCanceled) return;
                                    switch (response.formValues[0]) {
                                        case 0:
                                            player.runCommand(`structure load mh_1 ~-7 ~ ~-12 ${rotation}`)
                                            break
                                        case 1:
                                            player.runCommand(`structure load mh_2 ~-15 ~-3 ~-36 ${rotation}`)
                                            break
                                        case 2:
                                            player.runCommand(`structure load mh_3 ~-20 ~-3 ~-43 ${rotation}`)
                                            break
                                        case 3:
                                            player.runCommand(`structure load mh_4 ~-20 ~-3 ~-33 ${rotation}`)
                                            break
                                        case 4:
                                            player.runCommand(`structure load mh_5 ~-20 ~-1 ~-39 ${rotation}`)
                                            break
                                        case 5:
                                            player.runCommand(`structure load mh_6 ~ ~-9 ~ ${rotation}`)
                                            break
                                        case 6:
                                            player.runCommand(`structure load mh_7 ~-7 ~-2 ~-33 ${rotation}`)
                                            break
                                        case 7:
                                            player.runCommand(`structure load mh_8 ~-17 ~-1 ~-26 ${rotation}`)
                                            break
                                        case 8:
                                            player.runCommand(`structure load mh_9 ~-44 ~-2 ~ ${rotation}`)
                                            break
                                        case 9:
                                            player.runCommand(`structure load mh_10 ~-12 ~-2 ~ ${rotation}`)
                                            break
                                        case 10:
                                            player.runCommand(`structure load mh_11 ~-10 ~-2 ~1 ${rotation}`)
                                            break
                                        case 11:
                                            player.runCommand(`structure load mh_12 ~-17 ~-2 ~1 ${rotation}`)
                                            break
                                        case 12:
                                            player.runCommand(`structure load mh_13 ~-14 ~-2 ~-1 ${rotation}`)
                                            break
                                        case 13:
                                            player.runCommand(`structure load mh_14 ~-17 ~-2 ~-30 ${rotation}`)
                                            break
                                        case 14:
                                            player.runCommand(`structure load mh_15 ~-16 ~-2 ~-43 ${rotation}`)
                                            break
                                        case 15:
                                            player.runCommand(`structure load mh_16 ~-14 ~-2 ~ ${rotation}`)
                                            break
                                        case 16:
                                            player.runCommand(`structure load mh_17 ~-21 ~-3 ~1 ${rotation}`)
                                            break
                                        case 17:
                                            player.runCommand(`structure load mh_18 ~-7 ~-1 ~-36 ${rotation}`)
                                            break
                                        case 18:
                                            player.runCommand(`structure load mh_19 ~-13 ~-3 ~-53 ${rotation}`)
                                            break
                                        case 19:
                                            player.runCommand(`structure load mh_20 ~-40 ~-2 ~ ${rotation}`)
                                            break
                                    }
                                })
                                break
                            case 1:
                                let mdhouses = new ui.ModalFormData();
                                mdhouses.title("Select your structure")
                                mdhouses.dropdown("Houses", ['Medival 1', 'Medival 2', 'Medival 3', 'Medival 4', 'Medival 5', 'Medival 6', 'Medival 7', 'Medival 8', 'Medival 9', 'Medival 10'])
                                mdhouses.dropdown("Rotation", ['0_degrees', '90_degrees', '180_degrees', '270_degrees'], 0)

                                mdhouses.show(player).then((response) => {
                                    switch (response.formValues[1]) {
                                        case 0:
                                            rotation = '0_degrees'
                                            break
                                        case 1:
                                            rotation = '90_degrees'
                                            break
                                        case 2:
                                            rotation = '180_degrees'
                                            break
                                        case 3:
                                            rotation = '270_degrees'
                                            break
                                    }
                                    if (response.isCanceled) return;
                                    switch (response.formValues[0]) {
                                        case 0:
                                            player.runCommand(`structure load md_1 ~-10 ~-1 ~-30 ${rotation}`)
                                            break
                                        case 1:
                                            player.runCommand(`structure load md_2 ~-8 ~-1 ~-20 ${rotation}`)
                                            break
                                        case 2:
                                            player.runCommand(`structure load md_3 ~-12 ~-2 ~-17 ${rotation}`)
                                            break
                                        case 3:
                                            player.runCommand(`structure load md_4 ~-21 ~-1 ~-20 ${rotation}`)
                                            break
                                        case 4:
                                            player.runCommand(`structure load md_5 ~-11 ~-1 ~-24 ${rotation}`)
                                            break
                                        case 5:
                                            player.runCommand(`structure load md_6 ~-11 ~-1 ~4 ${rotation}`)
                                            break
                                        case 6:
                                            player.runCommand(`structure load md_7 ~-8 ~-1 ~-15 ${rotation}`)
                                            break
                                        case 7:
                                            player.runCommand(`structure load md_8 ~1 ~-3 ~-25 ${rotation}`)
                                            break
                                        case 8:
                                            player.runCommand(`structure load md_9 ~-19 ~ ~-11 ${rotation}`)
                                            break
                                        case 9:
                                            player.runCommand(`structure load md_10 ~-14 ~-3 ~-16 ${rotation}`)
                                            break
                                    }
                                })
                                break
                        }
                    })
                    break;
                case 1:
                    let trees = new ui.ActionFormData();
                    trees.title("Tree Type")
                    trees.button("Regular", 'textures/icons/tree_icon.png')
                    trees.button("Mushroom", 'textures/icons/mush_icon.png')
                    trees.button("Other")
                    trees.show(player).then((response) => {
                        if (response.isCanceled) return;
                        switch (response.selection) {
                            case 0:
                                let tree = new ui.ModalFormData();
                                tree.title("Select your structure")
                                tree.dropdown("Trees", ['Tree 1', 'Tree 2', 'Tree 3', 'Tree 4', 'Tree 5', 'Tree 6', 'Tree 7', 'Tree 8', 'Tree 9', 'Tree 10'])
                                tree.dropdown("Rotation", ['0_degrees', '90_degrees', '180_degrees', '270_degrees'], 0)

                                tree.show(player).then((response) => {
                                    switch (response.formValues[1]) {
                                        case 0:
                                            rotation = '0_degrees'
                                            break
                                        case 1:
                                            rotation = '90_degrees'
                                            break
                                        case 2:
                                            rotation = '180_degrees'
                                            break
                                        case 3:
                                            rotation = '270_degrees'
                                            break
                                    }
                                    if (response.isCanceled) return;
                                    switch (response.formValues[0]) {
                                        case 0:
                                            player.runCommand(`structure load tree_01 ~ ~-1 ~ ${rotation}`)
                                            break
                                        case 1:
                                            player.runCommand(`structure load tree_02 ~ ~-1 ~ ${rotation}`)
                                            break
                                        case 2:
                                            player.runCommand(`structure load tree_03 ~ ~ ~ ${rotation}`)
                                            break
                                        case 3:
                                            player.runCommand(`structure load tree_04 ~ ~ ~ ${rotation}`)
                                            break
                                        case 4:
                                            player.runCommand(`structure load tree_05 ~ ~ ~ ${rotation}`)
                                            break
                                        case 5:
                                            player.runCommand(`structure load tree_06 ~ ~ ~ ${rotation}`)
                                            break
                                        case 6:
                                            player.runCommand(`structure load tree_07 ~ ~ ~ ${rotation}`)
                                            break
                                        case 7:
                                            player.runCommand(`structure load tree_08 ~ ~ ~ ${rotation}`)
                                            break
                                        case 8:
                                            player.runCommand(`structure load tree_09 ~ ~ ~ ${rotation}`)
                                            break
                                        case 9:
                                            player.runCommand(`structure load tree_10 ~ ~ ~ ${rotation}`)
                                            break
                                    }
                                })
                                break;
                            case 1:
                                let tree1 = new ui.ModalFormData();
                                tree1.title("Select your structure")
                                tree1.dropdown("Trees", ['Mushroom 1', 'Mushroom 2', 'Mushroom 3', 'Mushroom 4', 'Mushroom 5', 'Mushroom 6', 'Mushroom 7', 'Mushroom 8', 'Mushroom 9'])
                                tree1.dropdown("Rotation", ['0_degrees', '90_degrees', '180_degrees', '270_degrees'], 0)

                                tree1.show(player).then((response) => {
                                    switch (response.formValues[1]) {
                                        case 0:
                                            rotation = '0_degrees'
                                            break
                                        case 1:
                                            rotation = '90_degrees'
                                            break
                                        case 2:
                                            rotation = '180_degrees'
                                            break
                                        case 3:
                                            rotation = '270_degrees'
                                            break
                                    }
                                    if (response.isCanceled) return;
                                    switch (response.formValues[0]) {
                                        case 0:
                                            player.runCommand(`structure load tree_mr1 ~ ~-1 ~ ${rotation}`)
                                            break
                                        case 1:
                                            player.runCommand(`structure load tree_mr2 ~ ~-1 ~ ${rotation}`)
                                            break
                                        case 2:
                                            player.runCommand(`structure load tree_mr3 ~ ~ ~ ${rotation}`)
                                            break
                                        case 3:
                                            player.runCommand(`structure load tree_mr4 ~ ~ ~ ${rotation}`)
                                            break
                                        case 4:
                                            player.runCommand(`structure load tree_mr5 ~ ~ ~ ${rotation}`)
                                            break
                                        case 5:
                                            player.runCommand(`structure load tree_mr6 ~ ~ ~ ${rotation}`)
                                            break
                                        case 6:
                                            player.runCommand(`structure load tree_mr7 ~ ~ ~ ${rotation}`)
                                            break
                                        case 7:
                                            player.runCommand(`structure load tree_mr8 ~ ~ ~ ${rotation}`)
                                            break
                                        case 8:
                                            player.runCommand(`structure load tree_mr9 ~ ~ ~ ${rotation}`)
                                            break
                                    }
                                })
                                break
                            case 2:
                                let otherTree = new ui.ModalFormData();
                                otherTree.title("Select your structure")
                                otherTree.dropdown("Other Trees", ['Cactus 1', 'Cactus 2', 'Cactus 3', 'Cactus 4', 'Cactus 5', 'Oak Tree', 'Orange Tree', 'Pink Tree', 'White Tree'])
                                otherTree.dropdown("Rotation", ['0_degrees', '90_degrees', '180_degrees', '270_degrees'], 0)

                                otherTree.show(player).then((response) => {
                                    switch (response.formValues[1]) {
                                        case 0:
                                            rotation = '0_degrees'
                                            break
                                        case 1:
                                            rotation = '90_degrees'
                                            break
                                        case 2:
                                            rotation = '180_degrees'
                                            break
                                        case 3:
                                            rotation = '270_degrees'
                                            break
                                    }
                                    if (response.isCanceled) return;
                                    switch (response.formValues[0]) {
                                        case 0:
                                            player.runCommand(`structure load tree_ct1 ~ ~ ~ ${rotation}`)
                                            break
                                        case 1:
                                            player.runCommand(`structure load tree_ct2 ~ ~ ~ ${rotation}`)
                                            break
                                        case 2:
                                            player.runCommand(`structure load tree_ct3 ~ ~ ~ ${rotation}`)
                                            break
                                        case 3:
                                            player.runCommand(`structure load tree_ct4 ~ ~ ~ ${rotation}`)
                                            break
                                        case 4:
                                            player.runCommand(`structure load tree_ct5 ~ ~ ~ ${rotation}`)
                                            break
                                        case 5:
                                            player.runCommand(`structure load tree_oak1 ~ ~ ~ ${rotation}`)
                                            break
                                        case 6:
                                            player.runCommand(`structure load tree_orange ~-8 ~ ~-13 ${rotation}`)
                                            break
                                        case 7:
                                            player.runCommand(`structure load tree_pink ~-8 ~ ~-13 ${rotation}`)
                                            break
                                        case 8:
                                            player.runCommand(`structure load tree_white ~-8 ~ ~-13 ${rotation}`)
                                            break
                                    }
                                })
                                break;
                        }
                    })
                    break
                case 2:
                    let other = new ui.ModalFormData();
                    other.title("Select your structure")
                    other.dropdown("Structures", ['Charmender', 'Chikorita', 'Blooper'])
                    other.dropdown("Rotation", ['0_degrees', '90_degrees', '180_degrees', '270_degrees'], 0)

                    other.show(player).then((response) => {
                        switch (response.formValues[1]) {
                            case 0:
                                rotation = '0_degrees'
                                break
                            case 1:
                                rotation = '90_degrees'
                                break
                            case 2:
                                rotation = '180_degrees'
                                break
                            case 3:
                                rotation = '270_degrees'
                                break
                        }
                        if (response.isCanceled) return;
                        switch (response.formValues[0]) {
                            case 0:
                                player.runCommand(`structure load rs_charmender ~-60 ~ ~-22 ${rotation}`)
                                break
                            case 1:
                                player.runCommand(`structure load rs_chikorita ~-20 ~ ~-70 ${rotation}`)
                                break
                            case 2:
                                player.runCommand(`structure load rs_blooper ~-24 ~ ~-20 ${rotation}`)
                                break
                        }
                    })

            }
        }
        )
    }
}
)

